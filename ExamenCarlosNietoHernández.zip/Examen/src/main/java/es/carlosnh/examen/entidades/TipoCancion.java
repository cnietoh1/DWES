package es.carlosnh.examen.entidades;

public enum TipoCancion {
    CLÁSICA, FLAMENCO, ROCK, POP_URBAN, TRAP
}
